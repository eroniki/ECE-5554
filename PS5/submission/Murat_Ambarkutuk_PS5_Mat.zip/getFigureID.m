function n = getFigureID()
h =  findobj('type','figure');
n = length(h)+1;
end

